import React, { useContext, useState } from "react";
import { FinanceContext } from "../context/FinanceContext";
import "../Pages/Expenses.css";
import { formatCurrency } from "../utils/FinanceUtils";

const Expenses = () => {
  const { transactions, setTransactions } = useContext(FinanceContext);
  const [editId, setEditId] = useState(null);
  const [editData, setEditData] = useState({
    name: "",
    source: "",
    category: "",
    amount: "",
  });

  const handleDelete = (id) => {
    if (window.confirm("Delete this transaction?")) {
      setTransactions(transactions.filter((t) => t.id !== id));
    }
  };

  const handleEdit = (transaction) => {
    setEditId(transaction.id);
    setEditData({
      name: transaction.name,
      source: transaction.source,
      category: transaction.category,
      amount: transaction.amount,
    });
  };

  const handleSave = () => {
    setTransactions(
      transactions.map((t) =>
        t.id === editId
          ? { ...t, ...editData, amount: parseFloat(editData.amount) }
          : t
      )
    );
    setEditId(null);
  };

  const handleChange = (e) => {
    setEditData({ ...editData, [e.target.name]: e.target.value });
  };

  return (
    <div className="expenses-page">
      <h1 className="expenses-title">Mini Statement</h1>

      {transactions.length === 0 ? (
        <p className="no-transactions">No transactions yet</p>
      ) : (
        <>
          <div className="table-container">
            <table className="transactions-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Type</th>
                  <th>Source / Name</th>
                  <th>Category</th>
                  <th>Amount (₹)</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((t) => (
                  <tr key={t.id}>
                    <td>{t.date}</td>
                    <td
                      className={
                        t.type === "income" ? "type-income" : "type-expense"
                      }
                    >
                      {t.type}
                    </td>
                    <td>
                      {editId === t.id ? (
                        <input
                          type="text"
                          name={t.type === "income" ? "source" : "name"}
                          value={
                            t.type === "income"
                              ? editData.source
                              : editData.name
                          }
                          onChange={handleChange}
                        />
                      ) : t.type === "income" ? (
                        t.source
                      ) : (
                        t.name
                      )}
                    </td>
                    <td>
                      {t.type === "income" ? (
                        "Income"
                      ) : editId === t.id ? (
                        <select
                          name="category"
                          value={editData.category}
                          onChange={handleChange}
                        >
                          <option value="General">General</option>
                          <option value="Food">Food</option>
                          <option value="Travel">Travel</option>
                          <option value="Shopping">Shopping</option>
                          <option value="Bills">Bills</option>
                          <option value="Health">Health</option>
                        </select>
                      ) : (
                        t.category
                      )}
                    </td>
                    <td className={t.type === "income" ? "income" : "expense"}>
                      {editId === t.id ? (
                        <input
                          type="number"
                          name="amount"
                          value={editData.amount}
                          onChange={handleChange}
                        />
                      ) : (
                        `${formatCurrency(t.amount)}`
                      )}
                    </td>
                    <td className="actions">
                      {editId === t.id ? (
                        <>
                          <button className="save-btn" onClick={handleSave}>
                            Save
                          </button>
                          <button
                            className="cancel-btn"
                            onClick={() => setEditId(null)}
                          >
                            Cancel
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            className="edit-btn"
                            onClick={() => handleEdit(t)}
                          >
                            Edit
                          </button>
                          <button
                            className="delete-btn"
                            onClick={() => handleDelete(t.id)}
                          >
                            Delete
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <button
            style={{
              marginTop: 24,
              background: "linear-gradient(135deg, #4ca1af, #2980b9)",
              color: "#fff",
              border: "none",
              borderRadius: 8,
              padding: "12px 28px",
              fontSize: 16,
              fontWeight: 600,
              cursor: "pointer",
              boxShadow: "0 2px 8px rgba(41, 128, 185, 0.10)",
              transition: "background 0.3s, transform 0.2s",
              display: "block",
              marginLeft: "auto",
              marginRight: "auto",
            }}
            onClick={async () => {
              const jsPDFModule = await import("jspdf");
              const autoTableModule = await import("jspdf-autotable");
              const doc = new jsPDFModule.default();
              doc.text("Mini Statement", 14, 16);
              doc.autoTable = autoTableModule.default;
              doc.autoTable({
                startY: 22,
                head: [
                  ["Date", "Type", "Source/Name", "Category", "Amount (₹)"],
                ],
                body: transactions.map((t) => [
                  t.date,
                  t.type,
                  t.type === "income" ? t.source : t.name,
                  t.type === "income" ? "Income" : t.category,
                  t.amount,
                ]),
              });
              doc.save("mini-statement.pdf");
            }}
          >
            Download PDF
          </button>
        </>
      )}
    </div>
  );
};

export default Expenses;
