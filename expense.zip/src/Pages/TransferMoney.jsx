import React from "react";

const TransferMoney = () => {
  return <div>TransferMoney</div>;
};

export default TransferMoney;
