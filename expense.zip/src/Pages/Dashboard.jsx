// src/Pages/Dashboard.jsx
import React, { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../context/UserContext"; //custom hook // give user data
import { FinanceContext } from "../context/FinanceContext";
import { Pie } from "react-chartjs-2";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
  CartesianGrid,
} from "recharts";
import "chart.js/auto";
import "./Dashboard.css";
import { formatCurrency } from "../utils/FinanceUtils";

//user Component
const Dashboard = () => {
  const { user } = useUser();
  const { transactions } = useContext(FinanceContext);
  const navigate = useNavigate();

  //display user name
  const firstName = user?.email
    ? user.email.split("@")[0]
    : user?.name
    ? user.name.split(" ")[0]
    : "Guest";

  // Separate transactions
  const incomeTransactions = transactions.filter((t) => t.type === "income");
  const expenseTransactions = transactions.filter((t) => t.type === "expense");
  const loanTransactions = transactions.filter((t) => t.type === "loan");

  // Totals calculate
  const totalIncome = incomeTransactions.reduce((sum, t) => sum + t.amount, 0);
  const totalExpense = expenseTransactions.reduce(
    (sum, t) => sum + t.amount,
    0
  );
  const totalLoan = loanTransactions.reduce((sum, t) => sum + t.amount, 0);

  // Balance nikalna
  const balance = totalIncome + totalLoan - totalExpense;

  // Expense Pie Chart (by Category)
  const categories = [...new Set(expenseTransactions.map((e) => e.category))];
  const expenseChartData = {
    labels: categories,
    datasets: [
      {
        data: categories.map((cat) =>
          expenseTransactions
            .filter((e) => e.category === cat)
            .reduce((sum, e) => sum + e.amount, 0)
        ),
        backgroundColor: [
          "#e15759",
          "#f28e2b",
          "#76b7b2",
          "#59a14f",
          "#4e79a7",
        ],
        borderColor: "#f7f7f7ff",
        borderWidth: 2,
      },
    ],
  };

  // Income Pie Chart (by Source)
  const incomeSources = [...new Set(incomeTransactions.map((i) => i.source))];
  const incomeChartData = {
    labels: incomeSources,
    datasets: [
      {
        data: incomeSources.map((src) =>
          incomeTransactions
            .filter((i) => i.source === src)
            .reduce((sum, i) => sum + i.amount, 0)
        ),
        backgroundColor: [
          "#b7c35bff",
          "#47728fff",
          "#8e44ad",
          "#f39c12",
          "#c0392b",
        ],
        borderColor: "#ffffff",
        borderWidth: 2,
      },
    ],
  };

  // Loan Pie Chart (by Lender)
  const loanLenders = [
    ...new Set(loanTransactions.map((l) => l.name || l.lender)),
  ];
  const loanChartData = {
    labels: loanLenders,
    datasets: [
      {
        data: loanLenders.map((lender) =>
          loanTransactions
            .filter((l) => (l.name || l.lender) === lender)
            .reduce((sum, l) => sum + l.amount, 0)
        ),
        backgroundColor: [
          "#b384bfff",
          "#549f90ff",
          "#d35400",
          "#7f8c8d",
          "#913954ff",
        ],
        borderColor: "#ffffff",
        borderWidth: 2,
      },
    ],
  };

  return (
    <div className="dashboard">
      <div className="user-info">
        <h2>Welcome, {firstName} 👋</h2>
      </div>

      <div className="summary-cards">
        <div className="card income">
          <h3>Total Income</h3>
          <p>{formatCurrency(totalIncome)}</p>
        </div>
        <div className="card expense">
          <h3>Total Expense</h3>
          <p>{formatCurrency(totalExpense)}</p>
        </div>
        <div className="card balance">
          <h3>Balance</h3>
          <p>{formatCurrency(balance)}</p>
        </div>
        <div className="card loan">
          <h3>Total Loan Taken</h3>
          <p>{formatCurrency(totalLoan)}</p>
        </div>
      </div>

      <div
        className="charts-row"
        style={{
          display: "flex",
          gap: 24,
          justifyContent: "center",
          flexWrap: "wrap",
          marginTop: 32,
        }}
      >
        <div
          className="chart-container"
          style={{ flex: 1, minWidth: 260, maxWidth: 340 }}
        >
          <h3>Expense by Category</h3>
          {categories.length > 0 ? (
            <Pie data={expenseChartData} />
          ) : (
            <p>No expense data available</p>
          )}
        </div>
        <div
          className="chart-container"
          style={{ flex: 1, minWidth: 260, maxWidth: 340 }}
        >
          <h3>Income by Source</h3>
          {incomeSources.length > 0 ? (
            <Pie data={incomeChartData} />
          ) : (
            <p>No income data available</p>
          )}
        </div>
        <div
          className="chart-container"
          style={{ flex: 1, minWidth: 260, maxWidth: 340 }}
        >
          <h3>Loan by Lender</h3>
          {loanLenders.length > 0 ? (
            <Pie data={loanChartData} />
          ) : (
            <p>No loan data available</p>
          )}
        </div>
      </div>

      <button
        className="add-expense-btn"
        onClick={() => navigate("/add-transaction")}
      >
        + Add Transaction
      </button>
    </div>
  );
};

export default Dashboard;
